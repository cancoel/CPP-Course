// Testtreiber für Aufgabe 2.1: my::vector
// Autor: Hartmut Schirmacher

#include <iostream>
#include <cassert>
#include "../my_vector.h"
#include "../payload.h"

void test_22()
{
    using my::vector;
    using std::cout;
    using std::endl;  

#if 0

#endif

} // test21()
